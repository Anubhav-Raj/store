<?php
include "../config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

if(($_SERVER['REQUEST_METHOD'] == 'POST'))
{ 
    if(empty(trim($_POST["username"])) || empty(trim($_POST['password'])) )
    {
    
    echo json_encode(["messege"=>"Username /password cannot be blank"]);
    exit();
  }
    
    
     if(!empty($name=$_POST['username'])&& !empty($password=$_POST['password']))
     {
         
         if(strlen($name)<=5)
         {
             echo json_encode(["messege"=>"Username shoud be less than 5 are not allowes"]);
              exit();
         }
         
        
         if(strlen($password)<=5)
         {
             echo json_encode(["Messege"=>"Password should be  less then 5 are not allows"]);
             exit();
         }
        }
    
    $query="select * from users where username='$name' and password='$password'";
    $r=mysqli_query($conn,$query);

    if(mysqli_num_rows($r)>=1)
    {
        echo json_encode(["Status"=>1,"message"=>"success login"]);
    }
    else
        {
            echo json_encode(["Status"=>2,"message"=>"invalid credistional"]);
        }
}





?>