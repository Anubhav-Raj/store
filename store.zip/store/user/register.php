<?php
include "../config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");


if(($_SERVER['REQUEST_METHOD'] == 'POST'))
{
    if(!empty($name=$_POST['username'])&& !empty($password=$_POST['password']))
{
    if(empty(trim($_POST["username"])) || empty(trim($_POST['password'])) )
    {
    
    echo json_encode(["messege"=>"Username /password cannot be blank"]);
    exit();
  }

    if(strlen($name)<=5)
    {
        echo json_encode(["messege"=>"Username shoud be less than 5 are not allowes"]);
         exit();
    }
    if(strlen($password)<=5)
    {
        echo json_encode(["Messege"=>"Password should be  less then 5 are not allows"]);
        exit();
    }
    $q="select * from users where username='$name'";
    $u=mysqli_query($conn,$q);
    if(mysqli_num_rows($u)>0)
    {
        echo json_encode(["Messege"=>"username already exists"]);

    }
    else
    {
    $query="insert into users (username,password) values('$name','$password')";
    $res=mysqli_query($conn,$query);

    if($res)
    {
        echo json_encode(["message"=>"user registerd successfully"]);
    }
    else
    {
        echo  json_encode(["message"=>"user registerd not successfully"]);
    }
}
}
}
?>